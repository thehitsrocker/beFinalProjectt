
   <footer class="page-footer  orange lighten-1">
          
            <div class="container text-lighten-4" style="padding-bottom: 1%; font-size: 18px;">
            © 2017 All Rights Reserved.
          
            <a class="grey-text text-lighten-4 right" href="https://www.mygov.in/">More Info</a> 
            </div>
        </footer>
            

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="./js/materialize.min.js"></script>
<script src="./js/custom.js"></script>


</body>
</html>
<?php
require(dirname(__FILE__).'/../vendor/autoload.php');
$app_id = getenv('309695');
$app_key = getenv('4b2320cd75710151e68d');
$app_secret = getenv('002eed6d0246db5b69ca');
$pusher = new Pusher($app_key, $app_secret, $app_id);
$text = htmlspecialchars($_POST['message']);
$data['message'] = $text;
$pusher->trigger('notifications', 'new_notification', $data);
?>
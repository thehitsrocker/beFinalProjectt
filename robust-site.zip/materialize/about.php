<?php include('./head.php'); ?>
<title> About - Robust App </title>
</head>
<body class="green lighten-2">

<?php include('./nav.php'); ?>

    <div class="parallax-container">
      <div class="parallax"><img src="img/cover.png"></div>
    </div>

<div class="container" style="height: 100%;">

	<div class="about white-text">

	<h3 class="center-align">About us</h3>
	<hr style="width: 40%; border: 1px solid white;">

	<h5>

	As long as human live, waste will be generated. Waste is defined as any material which could harm our environment. It represents no economic value to its owner or to an environment. Garbage management is the precise name for the collection, transportation and recycling of waste. Garbage management is the process of treating solid wastes and offers variety of solutions for recycling items that don’t belong to trash. Garbage management is an area which needs education and awareness for global preservation. The education for waste management is very critical to perseverance of global health and security of human mankind. Improper waste management and disposal causes serious impact on health, children being more vulnerable to these pollutants. Uncollected garbage obstructs storm waters runoff, resulting in the formation of stagnant water bodies that ultimately affects the citizens in the surrounding area. This is why in this project, citizens and the corporation has collaborated with each other to take responsibilities of waste management. In this system, a model has been made in which the collection of garbage has been made real time becomes breeding grounds of diseases. There is a lack of coordination and irregularity in cleaning of garbage bins and roads by Municipal Corporation which can be resolved by designing an effective web app. It ultimately affects the citizens in the surrounding area. This is why in this project, citizens and the corporation has collaborated with each other to take responsibilities of waste management. In this system, a model has been made in which the collection of garbage has been made real time.
	</h5>


  <center><a href="https://mygov.in/" class="waves-effect btn blue darken-4">MyGov.in</a></center>

  <hr style="width: 90%; border: 1px solid #0d47a1;">

	</div>

</div>

<div class="container">
<h3 class="center">Members</h3>
<div class="row">

<div class="col s12 l3">

	<div class="card blue darken-4">
            <div class="card-image">
              <img src="img/vicky.jpg">
              <span class="card-title">Vickey Melwani</span>
            </div>
            <div class="card-content">
              <p class="white-text"> B.E. in Computer Engineering, VESIT </p>
            </div>
            <div class="card-action">
              <a href="mailto:vm.vickymelwani330@gmail.com"><i class=" material-icons">mail_outline</i></a>
              <a href="tel:+917709364749" class="right"><i class=" material-icons">phone</i></a>
            </div>
     </div>
     </div>

<div class="col s12 l3">
     <div class="card blue darken-4">
            <div class="card-image">
              <img src="img/rohit.jpg">
              <span class="card-title">Rohit Sachdev</span>
            </div>
            <div class="card-content">
              <p class="white-text"> B.E. in Computer Engineering, VESIT </p>
            </div>
            <div class="card-action">
              <a href="mailto:rohitsachdev.reso@gmail.com"><i class=" material-icons">mail_outline</i></a>
              <a href="tel:+917666940882" class="right"><i class=" material-icons">phone</i></a>
            </div>
     </div>
</div>

<div class="col s12 l3">
     <div class="card blue darken-4">
            <div class="card-image">
              <img src="img/sagar.jpg">
              <span class="card-title">Sagar Amlani</span>
            </div>
            <div class="card-content">
              <p class="white-text"> B.E. in Computer Engineering, VESIT </p>
            </div>
            <div class="card-action">
              <a href="mailto:sunnycrazy156@gmail.com"><i class=" material-icons">mail_outline</i></a>
              <a href="tel:+919930884443" class="right"><i class=" material-icons">phone</i></a>
            </div>
     </div>
</div>     

<div class="col s12 l3">
         <div class="card blue darken-4">
            <div class="card-image">
              <img src="img/hitesh.jpg">
              <span class="card-title">Hitesh Chawla</span>
            </div>
            <div class="card-content">
              <p class="white-text"> B.E. in Computer Engineering, VESIT </p>
            </div>
            <div class="card-action">
              <a href="mailto:hiteshchawla969@yahoo.com"><i class=" material-icons">mail_outline</i></a>
              <a href="tel:+919730662645" class="right"><i class=" material-icons">phone</i></a>
            </div>
     </div>

</div>

</div>
</div>

<?php include('./footer.php'); ?>
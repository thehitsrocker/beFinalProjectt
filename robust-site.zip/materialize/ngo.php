<?php include('./head.php'); ?>
<title> NGO associations - Robust App</title>
</head>
<body class="green lighten-2">
<?php include ('./nav.php'); ?>
    <div class="parallax-container">
      <div class="parallax"><img src="img/cover.png"></div>
    </div>

<div class="page-wrapper">

<h3 class="center white-text">Non Government Organizations</h3>
<h5> We are also here to bridge the gap between you all and NGOs.
 If you have the social responsibilities within and want to work with NGOs or something to contribute for the community through them, here are some trusted NGOs for you all!</h5>

<br>
<br>
<center>
		<a class="waves-effect waves-light orange lighten-1 btn hoverable" href="http://www.anybodycanhelp.org">Anybody Can Help</a>
		<a class="waves-effect waves-light orange lighten-1 btn hoverable" href="http://m.facebook.com/sortvesit">Sort Vesit NGO</a>
		<a class="waves-effect waves-light orange lighten-1 btn hoverable" href="http://www.rcusg.esy.es/rcusg_website4">Rotract Club of Ulhasnagar</a>
		<a class="waves-effect waves-light orange lighten-1 btn hoverable" href="https://www.facebook.com/NSS-TSEC-732330450228924/">NSS TSEC </a>


</center>
	<br><br>
</div>
<?php include('./footer.php'); ?>
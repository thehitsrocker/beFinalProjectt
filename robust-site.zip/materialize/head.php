<!DOCTYPE html>
<html>
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<!-- Mobile friendly (Compulsion)  -->  

	<!-- Links -->
	<link rel="stylesheet" href="./css/materialize.min.css">
	<link rel="stylesheet" href="./css/custom.css">

	<!-- Material Icons -->
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">


  	<!-- Font Awesome Icons -->
	  <script src="https://use.fontawesome.com/0fd0e3f0a4.js"></script>
	


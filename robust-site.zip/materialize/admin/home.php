<?php
	session_start();
	if(isset($_SESSION['admin'])){
?>
<?php include('./includes/head.php'); ?>
<title> Admin Panel </title>
</head>
<body>
<?php include('./includes/side.php'); ?>

<div class="container">
<h2 style="text-align: center;">Admin Dashboard</h2> 
<br>
<div class="row">
	<div class="col-md-6">
	<div class="card" id="card1">
	<?php 
	include('./includes/config.php');

		$queries = "SELECT * FROM queries";
		$exequeries = mysqli_query($conn, $queries);

		$ques = mysqli_num_rows($exequeries);

	?>
	<h3>Queries<font style="float:right; color: white;"><?php echo $ques; ?></font></h3>
	</div>	
	</div>
	<div class="col-md-6">
	<div class="card" id="card2">
	<?php

		$users = "SELECT * FROM users";
		$exeusers = mysqli_query($conn, $users);

		$user = mysqli_num_rows($exeusers);

	?>
	<h3>Users<font style="float:right; color: white;"><?php echo $user; ?></font></h3>
	</div>	
	</div>

</div>

<h3 style="text-align: center;">Queries</h3>
<table class="table table-striped">

<thead>
<th>Sr. no</th><th>Locality</th><th>City</th><th>Pincode</th><th>Action</th><th>Status</th>
</thead>
<tbody>
<?php
	

	$sql = "SELECT * FROM queries";
	$query = mysqli_query($conn, $sql);

	static $srno = 1;

	while($row = mysqli_fetch_array($query)){
	
?>

<tr>
<td><?php echo $srno; ?></td><td><?php echo $row['street']; ?></td><td><?php echo $row['city']; ?></td><td><?php echo $row['zip']; ?></td><td><a href="./query.php?id=<?php echo $row['qid']; ?>" class="btn btn-default">More</a></td>
<td>


 <?php if($row['qstat']=='0'){ ?>
        <a class="btn btn-danger">Un-attended</a>
        <?php	} ?>
         <?php if($row['qstat']=='1'){ ?>
        <a class="btn btn-warning">In Progress</a>
        <?php	} ?>
         <?php if($row['qstat']=='2'){ ?>
        <a class="btn btn-success">Completed</a>
        <?php	} ?>
         <?php if($row['qstat']=='3'){ ?>
        <a class="btn btn-info disabled">Rejected</a>
        <?php	} ?>

</td>
</tr>

<?php 
	$srno++;

} ?>

</tbody>

</table>



</div>

<?php include('./includes/foot.php'); ?>
<?php
}else{
	header("Location: ./");
}
?>
<div class="navbar navbar-styled navbar-fixed-left">
<div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="fa fa-bars"></span>
      </button>
  <a class="navbar-brand" href="./">Brand</a>
  </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
  <ul class="nav navbar-nav">
   <li><a href="./home.php">Home</a></li>
   <li><a href="./users.php">Users</a></li>
   <li><a href="./wallet.php">Add to Wallet</a></li>
   <li><a href="./logout.php">Logout</a></li>
  </ul>
</div>
</div>
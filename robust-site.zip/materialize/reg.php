<?php

	include('./config.php');

	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$password = $_POST['password'];
	$status = "0";

	$pass = openssl_digest($password, 'sha512');

	$sql = "INSERT INTO users (uname, uemail, uphone, upass, status) VALUES ('$name', '$email', '$phone', '$pass','$status')";

	$query = mysqli_query($conn, $sql);


	$body = "You are one step away from a cleanliness revolution... just click link below to verify your account connect to us.";

	$body .="http://robust.esy.es/verify.php?email=".$email."&id=".$pass;


	
$headers = 'From: Robust <helpdesk@robut.esy.es>' . PHP_EOL .
    'Reply-To: Robust <helpdesk@robut.esy.es>' . PHP_EOL .
    'X-Mailer: PHP/' . phpversion();


	if($query){
			echo "Records added successfully.";
			

			mail($email, 'Verify your identity', $body, $headers);

			header("location: ./pending.php");
	} else {
		echo("Errorcode: " . mysqli_error($conn));
	}




?>